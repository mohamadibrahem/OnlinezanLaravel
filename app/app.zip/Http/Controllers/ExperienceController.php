<?php

namespace App\Http\Controllers;

use App\Experience;
use App\Lawyer;
use Auth;
use Illuminate\Http\Request;

class ExperienceController extends Controller
{
   /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
   public function index()
   {
      //
   }

   /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
   public function create()
   {
      return view('inner_page.experience.create');
   }

   /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
   public function store(Request $request)
   {
      $lawyer = Lawyer::where('user_id', Auth::user()->id)->get()['0'];
      $lawyer_id = $lawyer['id'];
      Experience::create([
         'name' => $request->get('name'),
         'description' => $request->get('description'),
         'lawyer_id' => $lawyer_id,
      ]);

      return redirect()->back()->with(['messages' => 'Успешно добавлено!']);
   }

   /**
   * Display the specified resource.
   *
   * @param  \App\Experience  $experience
   * @return \Illuminate\Http\Response
   */
   public function show(Experience $experience)
   {
      //
   }

   /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Experience  $experience
   * @return \Illuminate\Http\Response
   */
   public function edit(Experience $experience)
   {
      //
   }

   /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\Experience  $experience
   * @return \Illuminate\Http\Response
   */
   public function update(Request $request, Experience $experience)
   {
      //
   }

   /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Experience  $experience
   * @return \Illuminate\Http\Response
   */
   public function destroy(Experience $experience)
   {
      //
   }
}
