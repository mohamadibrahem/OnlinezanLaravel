<?php

namespace App\Http\Controllers;

use App\LawyersCategory;
use Illuminate\Http\Request;

class LawyersCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\LawyersCategory  $lawyersCategory
     * @return \Illuminate\Http\Response
     */
    public function show(LawyersCategory $lawyersCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\LawyersCategory  $lawyersCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(LawyersCategory $lawyersCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\LawyersCategory  $lawyersCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LawyersCategory $lawyersCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LawyersCategory  $lawyersCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(LawyersCategory $lawyersCategory)
    {
        //
    }
}
