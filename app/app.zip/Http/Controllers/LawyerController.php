<?php

namespace App\Http\Controllers;

use App\Lawyer;
use App\Service;
use App\Experience;
use App\Education;

use Illuminate\Http\Request;

class LawyerController extends Controller
{
   /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
   public function index()
   {
      $lawyers = Lawyer::all();
      $specializations = Service::all();
      $data = [
         'lawyers' => $lawyers,
         'specializations' => $specializations,
      ];

      return view('inner_page.lawyers.index', compact('data'));
   }

   /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
   public function create()
   {
      //
   }

   /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
   public function store(Request $request)
   {
      //
   }

   /**
   * Display the specified resource.
   *
   * @param  \App\Lawyer  $lawyer
   * @return \Illuminate\Http\Response
   */

   public function info(Lawyer $lawyer, Request $request)
   {
      $lawyer_id = request()->lawyer_id;
      $lawyer = Lawyer::where('id', $lawyer_id)->get()['0'];
      $lawyer_fullname = $lawyer->user['lastname'].' '.$lawyer->user['firstname'];
      $lawyer_price = $lawyer->urgent_consultation_price;
      $data = [
         'lawyer_fullname' => $lawyer_fullname,
         'lawyer_price' => $lawyer_price
      ];

      return response()->json($data, 200);
   }


   public function show(Lawyer $lawyer)
   {
      $experiences = Experience::where('lawyer_id', $lawyer->id)->get();
      $education = Education::where('lawyer_id', $lawyer->id)->get();

      $data = [
         'lawyer' => $lawyer,
         'experience' => $experiences,
         'education' => $education,
      ];

      return view('inner_page.lawyers.show', compact('data'));
   }

   /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Lawyer  $lawyer
   * @return \Illuminate\Http\Response
   */
   public function edit(Lawyer $lawyer)
   {
      //
   }

   /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\Lawyer  $lawyer
   * @return \Illuminate\Http\Response
   */
   public function update(Request $request, Lawyer $lawyer)
   {
      //
   }

   /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Lawyer  $lawyer
   * @return \Illuminate\Http\Response
   */
   public function destroy(Lawyer $lawyer)
   {
      //
   }
}
