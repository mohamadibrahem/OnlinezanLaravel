<?php

namespace App\Http\Controllers;

use App\UrgentConsultation;
use Illuminate\Http\Request;
use Auth;
use App\Lawyer;
use App\Client;

class UrgentConsultationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $consultations = UrgentConsultation::all();
      return view('inner_page.urgent_consultations.index', compact('consultations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $clients = Client::where('user_id', Auth::user()->id)->get()['0'];
      $client_id = $clients['id'];
      $client_phone = $clients->user['phone'];

      $consultation = UrgentConsultation::create([
         'status' => 'new',
         'client_id' => $client_id,
         'client_phone' => $client_phone,
         'lawyer_id' => $request->get('urgent_lawyer_id'),
      ]);
      // }

      return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\UrgentConsultation  $urgentConsultation
     * @return \Illuminate\Http\Response
     */
    public function show(UrgentConsultation $urgentConsultation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\UrgentConsultation  $urgentConsultation
     * @return \Illuminate\Http\Response
     */
    public function edit(UrgentConsultation $urgentConsultation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UrgentConsultation  $urgentConsultation
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UrgentConsultation $urgentConsultation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UrgentConsultation  $urgentConsultation
     * @return \Illuminate\Http\Response
     */
    public function destroy(UrgentConsultation $urgentConsultation)
    {
        //
    }
}
