<?php

namespace App\Http\Controllers;

use App\LawyerType;
use Illuminate\Http\Request;

class LawyerTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\LawyerType  $lawyerType
     * @return \Illuminate\Http\Response
     */
    public function show(LawyerType $lawyerType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\LawyerType  $lawyerType
     * @return \Illuminate\Http\Response
     */
    public function edit(LawyerType $lawyerType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\LawyerType  $lawyerType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LawyerType $lawyerType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LawyerType  $lawyerType
     * @return \Illuminate\Http\Response
     */
    public function destroy(LawyerType $lawyerType)
    {
        //
    }
}
