<?php

namespace App\Http\Controllers;

use App\OnlineConsultation;
use App\Client;
use App\Lawyer;

use Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;

class OnlineConsultationController extends Controller
{
   /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
   public function index()
   {
      $consultations = OnlineConsultation::all();
      $clients = Client::all();
      $lawyers = Lawyer::all();
      $now_datetime = Carbon::now();

      if(Auth::check()){
         $user = Auth::user();
         $userrole = $user->role_id;
      }else{
         $user = '';
         $userrole = '';
      }

      $lawyerid = '';
      foreach($lawyers as $item){
         if($user->id == $item->user_id){
            $lawyerid = $item->id;
         }
      }

      $clientid = '';
      foreach($clients as $item){
         if($user->id == $item->user_id){
            $clientid = $item->id;
         }
      }


      $coming_consultations = [];


      foreach ($consultations as $value) {
         if($user->role_id == 3){
            if($value->lawyer_id == $lawyerid){
               $coming_consultations[] = $value;
            }
         }
         elseif($user->role_id == 4){
            if($value->client_id == $clientid){
               $coming_consultations[] = $value;
            }
         }
      }



      $coming_consultations = collect($coming_consultations)->all();

      return view('inner_page.online_consultations.index', compact('coming_consultations'));
   }

   /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
   public function create()
   {
      //
   }

   /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
   public function store(Request $request)
   {
      //
   }

   /**
   * Display the specified resource.
   *
   * @param  \App\OnlineConsultation  $onlineConsultation
   * @return \Illuminate\Http\Response
   */
   public function show(OnlineConsultation $onlineConsultation)
   {
      //
   }

   /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\OnlineConsultation  $onlineConsultation
   * @return \Illuminate\Http\Response
   */
   public function edit(OnlineConsultation $onlineConsultation)
   {
      //
   }

   /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\OnlineConsultation  $onlineConsultation
   * @return \Illuminate\Http\Response
   */
   public function update(Request $request, OnlineConsultation $onlineConsultation)
   {
      //
   }

   /**
   * Remove the specified resource from storage.
   *
   * @param  \App\OnlineConsultation  $onlineConsultation
   * @return \Illuminate\Http\Response
   */
   public function destroy(OnlineConsultation $onlineConsultation)
   {
      //
   }
}
