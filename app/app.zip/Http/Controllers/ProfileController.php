<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Storage;
use File;
use Auth;

use App\User;
use App\Lawyer;
use App\Client;
use App\LawyersSpecialization;
use App\LawyersCategory;
use App\Experience;
use App\Education;

use Illuminate\Support\Facades\Validator;

class ProfileController extends Controller
{
   public function index(){
      $user = Auth::user();
      $specializations = LawyersSpecialization::all();
      $categories = LawyersCategory::all();
      $lawyer = Lawyer::where('user_id', $user->id)->get();
      foreach ($lawyer as $value) {
         $lawyer = $value;
      }

      $experiences = Experience::where('lawyer_id', $lawyer->id)->get();
      $education = Education::where('lawyer_id', $lawyer->id)->get();

      $specialization_arr = [];
      foreach ($specializations as $key => $specialization){
         foreach (json_decode($lawyer->specialization_id) as $key => $spec){
            if($specialization->id == $spec){
               $specialization_arr[] = $specialization->name;
            }
         }
      }
      $specialization_name = rtrim(implode(', ', $specialization_arr), ',');


      $category_arr = [];
      foreach($categories as $category){
         foreach(json_decode($lawyer->category_id) as $cat){
            if($category->id == $cat){
               $category_arr[] = $category->name;
            }
         }
      }

      $category_name = rtrim(implode(', ', $category_arr), ',');


      $data = [
         'user' => $user,
         'specializations' => $specializations,
         'lawyer' => $lawyer,
         'specialization_name' => $specialization_name,
         'category_name' => $category_name,
         'experiences' => $experiences,
         'education' => $education,
         'categories' => $categories
      ];

      return view('inner_page.profile.index', compact('data'));

   }


   public function edit(){
      $user = Auth::user();
      $specializations = LawyersSpecialization::all();
      $categories = LawyersCategory::all();
      $lawyer = Lawyer::where('user_id', $user->id)->get();
      foreach ($lawyer as $value) {
         $lawyer = $value;
      }

      $experiences = Experience::where('lawyer_id', $lawyer->id)->get();
      $education = Education::where('lawyer_id', $lawyer->id)->get();

      $specialization_arr = [];
      foreach ($specializations as $key => $specialization){
         foreach (json_decode($lawyer->specialization_id) as $key => $spec){
            if($specialization->id == $spec){
               $specialization_arr[] = $specialization->name;
            }
         }
      }
      $specialization_name = rtrim(implode(', ', $specialization_arr), ',');


      $category_arr = [];
      foreach($categories as $category){
         foreach(json_decode($lawyer->category_id) as $cat){
            if($category->id == $cat){
               $category_arr[] = $category->name;
            }
         }
      }

      $category_name = rtrim(implode(', ', $category_arr), ',');


      $data = [
         'user' => $user,
         'specializations' => $specializations,
         'lawyer' => $lawyer,
         'specialization_name' => $specialization_name,
         'category_name' => $category_name,
         'experiences' => $experiences,
         'education' => $education,
         'categories' => $categories
      ];

      return view('inner_page.profile.edit', compact('data'));
   }


   public function update_user(Request $request){
      if($request->get('phone') != null){
         $phone = str_replace([' ', '(', ')', '-'], '', $request->get('phone'));
      }else{
         $phone = Auth::user()->phone;
      }

      $request->merge([
         'phone' => $phone,
      ]);


      if(Auth::user()->role_id == 4){

         Validator::make($request->all(), [
            'phone' => 'unique:users,phone,' . Auth::user()->id . ',id',
            'email' => 'unique:users,email,'. Auth::user()->id . ',id', 'email',
            'firstname' => 'required',
            'lastname' => 'required',
            ])->validate();

         }


         if(Auth::user()->role_id == 3){

            Validator::make($request->all(), [
               'phone' => 'unique:users,phone,' . Auth::user()->id . ',id',
               'email' => 'unique:users,email,'. Auth::user()->id . ',id', 'email',
               'firstname' => 'required',
               'lastname' => 'required',
               'specialization' => 'required',
               ])->validate();

               $lawyers = Lawyer::where('user_id','=',Auth::user()->id)->get();
               $lawyer = [];
               foreach ($lawyers as $item) {
                  $lawyer = $item;
               }

               if($request->get('urgent_consultation_price') != null){
                  $urgent_price = $request->get('urgent_price');
               }else{
                  $urgent_price = 0;
               }
               if($request->get('online_consultation_price') != null){
                  $online_price = $request->get('online_price');
               }else{
                  $online_price = 0;
               }

               $lawyer->where('user_id', Auth::user()->id)->update([
                  'specialization_id' => json_encode($request->get('specialization')),
                  'category_id' => json_encode($request->get('category')),
                  'city_id' => $request->get('city'),
                  'biography' => $request->get('biography'),
                  'services' => json_encode($request->get('services')),
                  'urgent_consultation_price' => $urgent_price,
                  'online_consultation_price' => $online_price,
               ]);

            }

            $user->where('id', Auth::user()->id)->update([
               'firstname'=> $request->get('firstname'),
               'lastname'=> $request->get('lastname'),
               'middlename'=> $request->get('middlename'),
               'phone'=> $phone,
               'email'=> $request->get('email'),
            ]);

            return redirect()->back();
         }


      }
