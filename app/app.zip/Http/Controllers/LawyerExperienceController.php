<?php

namespace App\Http\Controllers;

use App\LawyerExperience;
use Illuminate\Http\Request;

class LawyerExperienceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\LawyerExperience  $lawyerExperience
     * @return \Illuminate\Http\Response
     */
    public function show(LawyerExperience $lawyerExperience)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\LawyerExperience  $lawyerExperience
     * @return \Illuminate\Http\Response
     */
    public function edit(LawyerExperience $lawyerExperience)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\LawyerExperience  $lawyerExperience
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LawyerExperience $lawyerExperience)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LawyerExperience  $lawyerExperience
     * @return \Illuminate\Http\Response
     */
    public function destroy(LawyerExperience $lawyerExperience)
    {
        //
    }
}
