<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Lawyer;
use App\Client;


use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Storage;
use File;

class RegisterController extends Controller
{
   /*
   |--------------------------------------------------------------------------
   | Register Controller
   |--------------------------------------------------------------------------
   |
   | This controller handles the registration of new users as well as their
   | validation and creation. By default this controller uses a trait to
   | provide this functionality without requiring any additional code.
   |
   */

   use RegistersUsers;

   /**
   * Where to redirect users after registration.
   *
   * @var string
   */
   protected $redirectTo = '/';

   /**
   * Create a new controller instance.
   *
   * @return void
   */
   public function __construct()
   {
      $this->middleware('guest');
   }

   /**
   * Get a validator for an incoming registration request.
   *
   * @param  array  $data
   * @return \Illuminate\Contracts\Validation\Validator
   */
   protected function validator(array $data)
   {
      $phone = str_replace([' ', '(', ')', '-'], '', $data['phone']);
      $data = [
         'firstname'=> $data['firstname'],
         'lastname'=> $data['lastname'],
         'email'=> $data['email'],
         'phone'=> $phone,
         'password'=> $data['password'],
         'password_confirmation'=> $data['password_confirmation'],
      ];

      return Validator::make($data, [
         'firstname' => ['required', 'string', 'max:255'],
         'lastname' => ['required', 'string', 'max:255'],
         'phone' => ['required', 'unique:users', 'min:10'],
         'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
         'password' => ['required', 'string', 'min:6', 'confirmed'],
      ]);
   }

   /**
   * Create a new user instance after a valid registration.
   *
   * @param  array  $data
   * @return \App\User
   */
   protected function create(array $data)
   {

      $request = request();

      if ($request->hasFile('profile_photo')) {
         $profileImage = $request->file('profile_photo');
         $filename = time() . '_' . $profileImage->getClientOriginalName();
         $path = 'profile_photo/';
         $profileImage->move(public_path('uploads/'.$path), $filename);
         $photo = strval($path . $filename);
      }else{
         $photo = '';
      }

      if($data['user_type'] == 'lawyer'){
         $role = 3;
      }elseif($data['user_type'] == 'client'){
         $role = 4;
      }
      $user = User::create([
         'firstname' => mb_convert_case($data['firstname'], MB_CASE_TITLE, "UTF-8"),
         'lastname' => mb_convert_case($data['lastname'], MB_CASE_TITLE, "UTF-8"),
         'middlename' => mb_convert_case($data['middlename'], MB_CASE_TITLE, "UTF-8"),
         'email' => $data['email'],
         'phone' => str_replace([' ', '(', ')', '-'], '', $data['phone']),
         'profile_photo' => $photo,
         'status' => 'acceped',
         'role_id' => $role,
         'password' => bcrypt($data['password']),
      ]);

      if($role == 3){
         $lawyer = Lawyer::create([
            'user_id'=>$user->id,
            'status'=>'accepted',
            'specialization_id' => null,
            'category_id' => null,
            'city_id' => null,
            'online_consultation_price' => 0,
            'urgent_consultation_price' => 0,
            'education' => null,
            'biography' => null,
         ]);
      }
      elseif($role == 4){
         $client = Client::create([
            'user_id'=>$user->id,
            'status'=>'accepted',
         ]);
      }

      return $user;

   }
}
