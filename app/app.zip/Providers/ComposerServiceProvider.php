<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Service;
use App\Lawyer;
use Illuminate\Support\Facades\View;
use Illuminate\Http\Request;

class ComposerServiceProvider extends ServiceProvider
{
   /**
   * Bootstrap services.
   *
   * @return void
   */

   public function boot()
   {

      View::composer('main_page.index', function($view) {
         $services = Service::orderBy('weight', 'asc')->get();
         $lawyers = Lawyer::all();

         $view->with([
            'services' => $services,
            'lawyers' => $lawyers,
         ]);
      });


      View::composer('layouts.header', function($view) {
         $services = Service::all();

         $view->with([
            'services' => $services,
         ]);
      });
   }

   /**
   * Register services.
   *
   * @return void
   */
   public function register()
   {
      //
   }
}
