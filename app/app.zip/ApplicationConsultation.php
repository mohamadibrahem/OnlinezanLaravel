<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApplicationConsultation extends Model
{
   protected $fillable = [
      'client_name',
      'client_phone',
      'client_email',
      'user_type',
      'service',
      'comment',
   ];
}
